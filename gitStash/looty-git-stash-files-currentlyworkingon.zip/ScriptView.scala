package looty
package views

import cgta.oscala.util.debugging.PRINT
import looty.facades.jailed
import looty.poeapi.PoeCacher
import looty.poeapi.PoeTypes.Leagues
import looty.util.DurationText
import org.scalajs.jquery.{JQuery, JQueryStatic}

import scala.scalajs.js
import scala.scalajs.js.Dynamic



//////////////////////////////////////////////////////////////
// Copyright (c) 2015 Ben Jackman, Jeff Gomberg
// All Rights Reserved
// please contact ben@jackman.biz or jeff@cgtanalytics.com
// for licensing inquiries
// Created by bjackman @ 7/19/15 3:31 PM
//////////////////////////////////////////////////////////////


class ScriptView(implicit val pc: PoeCacher) extends View {
//  def toJs: js.Any = Dynamic.literal()
//  def time[R](block: => R): R = {
//    val t0 = System.nanoTime()
//    val result = block    // call-by-name
//    val t1 = System.nanoTime()
//    println("Elapsed time: " + (t1 - t0) + "ns")
//    result
//  }
  val jq: JQueryStatic = global.jQuery.asInstanceOf[JQueryStatic]
  override def start(ele: JQuery): Unit = {
  var el = ele.append("<div id='script'></div>")
  el = jq("#script")
    val start = System.currentTimeMillis()
    Alerter.info("Geting all items for the the Standard league...")
    val allItems = pc.getAllItems("Standard").map { items =>
      Alerter.info(s"You have hoardred ${items.size} items. ${if (items.size>10000) "WoW!" else "Your stash is almost empty ;)" }")
      val cntMap = MMap.empty[Int, Int].withDefaultValue(0)
      items.groupBy(_.item.icon).toList.sortBy(_._2.size).foreach {
        case (icon, items) =>
        if (items.size > 25) {
          val groupName = items.head.item.typeLine
          val listOfItemNames = for(item <- items.map(_.displayName).distinct) yield {
            //build list of items unique names
            s"<li class='item'>${item}</li>"
          }
          val listOfItems = s"""
					|<div class='category'>
					|  <a class='header' href='#' title=''>
					|      <div class='iconHelper'><img class='icon' src='${icon}'></div>
					|      <span class='sub'><span class='count'>${items.size} </span><span class='title'>duplicates</span></span>
					|  </a>
					|  <span class='groupName'>${groupName}</span>
					|  <ul class='duplicateItems'>
          |      ${listOfItemNames.mkString(", ")}
					|  </ul>
					|</div>
          |""".stripMargin
          el.append(listOfItems)
         //TODO on hover <span>duplicate</span> show locations of dups in table

        }
        cntMap(items.size) = cntMap(items.size) + 1
      }
    }
    val stop = System.currentTimeMillis() //doen't work :/
    //Alerter.info(s"You have ${DurationText.durationMs(stop - start, 1)}")
  }

  override def stop(): Unit = {

  }
}