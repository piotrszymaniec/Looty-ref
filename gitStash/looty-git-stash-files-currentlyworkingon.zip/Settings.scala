package looty.util

package object Settings {
	val devMode = false

}
