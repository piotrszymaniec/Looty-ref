//ScalaJS.modules.example_ScalaJSExample().main();

console.log("Startup.js start")
LootyMain().main()
console.log("Startup.js end")
